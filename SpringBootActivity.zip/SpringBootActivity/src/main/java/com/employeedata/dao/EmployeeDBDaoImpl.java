package com.employeedata.dao;

import com.employeedata.model.Employee;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collection;

@Repository
@Qualifier("dbData")
public class EmployeeDBDaoImpl implements EmployeeDao {


    @Override
    public Collection<Employee> getAllEmployees() {
        return new ArrayList<Employee>(){
            {
                add(new Employee(1, "Mario", "Nothing"));
            }
        };
    }

    @Override
    public Employee getEmployeeById(int id) {
        return null;
    }

    @Override
    public void removeEmployeeById(int id) {

    }

    @Override
    public void updateEmployee(Employee employee) {

    }

    @Override
    public void insertEmployeeToDb(Employee employee) {

    }
}
