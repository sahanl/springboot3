package com.employeedata.service;

import com.employeedata.dao.EmployeeDao;
import com.employeedata.dao.EmployeeDaoImpl;
import com.employeedata.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class EmployeeService {

    @Autowired
    @Qualifier("mapData")
    private EmployeeDao employeeDao;

    public Collection<Employee> getAllEmployees(){
        return this.employeeDao.getAllEmployees();
    }

    public Employee getEmployeeById(int id){
        return this.employeeDao.getEmployeeById(id);
    }


    public void removeEmployeeById(int id) {
        this.employeeDao.removeEmployeeById(id);
    }

    public void updateEmployee(Employee employee){
        this.employeeDao.updateEmployee(employee);
    }

    public boolean insertEmployee(Employee employee) {

        if(EmployeeDaoImpl.employees.containsKey(employee.getId())){
            return false;
        }else {
            employeeDao.insertEmployeeToDb(employee);
            return true;
        }
    }
}
